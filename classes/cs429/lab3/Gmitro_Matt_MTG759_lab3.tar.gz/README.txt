README.txt

No optimizations